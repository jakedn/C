#ifndef EPSILON_H
#define EPSILON_H
#define EPSILON (0.001) 
#endif //EPSILON_H